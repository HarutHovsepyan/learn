const translates = {
  en: {
    language: "Language is",
    name: "User name is",
    sureName: "User SureName is"
  },
  am: {
    language: "Լեզուն է",
    name: "Անունն է",
    sureName: "Ազգանունն է"
  }
};

export { translates };