import LanguageBar from '../../components/LanguageBar/LanguageBar';
import User from '../../components/User';

export default function Home() {
  return (<div>
    <div className="App">
    </div>
    <User />
    <LanguageBar />
  </div>);
}