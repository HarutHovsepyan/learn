import LanguageBar from './LanguageBar';

export default LanguageBar;