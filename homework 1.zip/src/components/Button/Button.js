function Button(props) {
  return (
    <div className='button'>
      Click Me
    </div>
  );
}

export default Button;