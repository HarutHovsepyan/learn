function selectCount(state) {
  return state.count
}
export {selectCount}