const PLUS = "@countType.PLUSE";
const MINUS = "@countType.MINUS";

export {
  PLUS,
  MINUS
}