const EDIT = "@postsTypes.EDIT";
const SELECT = "@postsTypes.SELECT";
const SET = "@postTypes.SET";

export {
  EDIT,
  SELECT,
  SET
}