import {PLUS,MINUS  } from "./countTypes";
import * as PostsTypes from "./postsTypes"

const CountTypes = {
  PLUS, MINUS 
}


export {CountTypes, PostsTypes };
